/**
 *
 * SM Shop By - Version 2.0.0
 * Copyright (c) 2017 YouTech Company. All Rights Reserved.
 * @license - Copyrighted Commercial Software
 * Author: YouTech Company
 * Websites: http://www.magentech.com
 */
var config = {
    "map": {
        "*": {
            "productListToolbarForm": "Sm_ShopBy/js/product/list/toolbar"
        }
    }
};