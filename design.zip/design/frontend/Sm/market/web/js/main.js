require(['jquery'], function(jQuery){
jQuery(document).ready(function(){
	    
jQuery(".fa.fa-search").click(function(){
jQuery(".searchbox-header").toggleClass("form-popup");
});

jQuery(".sidebar-main .block-title").click(function () {
	jQuery(".filter").addClass("active");
	jQuery(".filter-content").addClass("show-expanded");
});

jQuery(".close-expanded").click(function (){
    jQuery(".filter").removeClass("active");
    jQuery(".filter-content").removeClass("show-expanded");
});


// jQuery('.slder-panel-1').owlCarousel({
// loop: false,
// center: true,
// items:1,
// margin:0,
// autoplay: false,
// dots:false,
// nav:true,
// autoplayTimeout: 8500,
// smartSpeed: 450,
// responsive: {
// 0: {
// items: 1
// },
// 768: {
// items: 1
// },
// 1170: {
// items: 1
// }
// }
// });


});
});
