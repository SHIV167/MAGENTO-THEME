var config = {
    map: {
        '*': {
            'jquerybootstrap': "Sm_Market/js/bootstrap.min",
            'owlcarousel': "Sm_Market/js/owl.carousel",
            'jquerycookie': "Sm_Market/js/jquery.cookie.min",
            'jqueryfancyboxpack': "Sm_Market/js/jquery.fancybox.pack",
            'jqueryunveil': "Sm_Market/js/jquery.unveil",
            'yttheme': "Sm_Market/js/yttheme"
        }
    }
};